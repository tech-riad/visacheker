<footer class="footer">
  <div class="container-fluid d-flex justify-content-between">
    <span class="text-muted d-block text-center text-sm-start d-sm-inline-block">Copyright © PnH IT Solution 2023</span>
    <span class="float-none float-sm-end mt-1 mt-sm-0 text-end"> <a href="https://www.pnhbd.com/" target="_blank">Admin template</a> from PnH IT Solution</span>
  </div>
</footer>
