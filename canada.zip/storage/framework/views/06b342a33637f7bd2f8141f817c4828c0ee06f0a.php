<?php $__env->startSection('content'); ?>
        <!-- hero area start here -->
        <section class="slider-area fix">
            <div class="slider-active swiper-container">
                <div class="swiper-wrapper">
                    <div class="single-slider slider-height d-flex align-items-center swiper-slide"
                        data-swiper-autoplay="5000">
                        <div class="slide-bg" data-background="<?php echo e(asset('frontend/assets/img/hero/slider-bg-1.jpg')); ?>"></div>
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="aslider z-index">
                                        <span class="slider-top-text" data-animation="fadeInUp"
                                            data-delay=".5s">Effective Visa Solution</span>
                                        <h2 class="aslider--title mb-25" data-animation="fadeInUp" data-delay=".7s">Visa
                                            & Immigration <br> Consultation</h2>
                                        <p class="aslider--subtitle mb-40" data-animation="fadeInUp" data-delay=".9s">
                                            Our professionalism, honesty, sincerity & dedication to client service <br>
                                            has helped our clients to fulfill their wishes </p>
                                        <div class="aslider--btn" data-animation="fadeInUp" data-delay=".9s">
                                            <a href="contact.html" class="theme-btn blacks-hover">Book Now</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="single-slider slider-height d-flex align-items-center swiper-slide"
                        data-swiper-autoplay="5000">
                        <div class="slide-bg" data-background="<?php echo e(asset('frontend/assets/img/hero/slider-bg-3.jpg')); ?>"></div>
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="aslider z-index">
                                        <span class="slider-top-text" data-animation="fadeInUp"
                                            data-delay=".5s">Effective Visa Solution</span>
                                        <h2 class="aslider--title mb-25" data-animation="fadeInUp" data-delay=".7s">Visa
                                            & Immigration <br> Consultation</h2>
                                        <p class="aslider--subtitle mb-40" data-animation="fadeInUp" data-delay=".9s">
                                            Our professionalism, honesty, sincerity & dedication to client service <br>
                                            has helped our clients to fulfill their wishes </p>
                                        <div class="aslider--btn" data-animation="fadeInUp" data-delay=".9s">
                                            <a href="contact.html" class="theme-btn blacks-hover">Book Now</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- If we need navigation buttons -->
                <div class="swiper-button-prev slide-prev"><i class="far fa-long-arrow-left"></i></div>
                <div class="swiper-button-next slide-next"><i class="far fa-long-arrow-right"></i></div>
            </div>
        </section>
        <!-- hero area end here -->

        <!-- visa area start here -->
        <section class="visa-area theme-bg">
            <div class="container">
                <div class="row g-0">
                    <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-6 col-sm-6">
                        <div class="visa__items br-none">
                            <div class="visa__items-single d-flex align-items-center">
                                <div class="visa__items-single-icon">
                                    <i class="flaticon-passport"></i>
                                </div>
                                <h4 class="visa__items-single-title">
                                    <a href="#"> Online Visa
                                        Application</a>
                                </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-6 col-sm-6">
                        <div class="visa__items">
                            <div class="visa__items-single d-flex align-items-center">
                                <div class="visa__items-single-icon">
                                    <i class="flaticon-content"></i>
                                </div>
                                <h4 class="visa__items-single-title">
                                    <a href="#"> Visa
                                        Information</a>
                                </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-6 col-sm-6">
                        <div class="visa__items">
                            <div class="visa__items-single d-flex align-items-center">
                                <div class="visa__items-single-icon">
                                    <i class="flaticon-customer"></i>
                                </div>
                                <h4 class="visa__items-single-title">
                                    <a href="#">Immigration
                                        Resources</a>
                                </h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-6 col-sm-6">
                        <div class="visa__items">
                            <div class="visa__items-single d-flex align-items-center">
                                <div class="visa__items-single-icon">
                                    <i class="flaticon-passport-1"></i>
                                </div>
                                <h4 class="visa__items-single-title">
                                    <a href="#">Online
                                        Passport Application</a>
                                </h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- visa area end here -->

        <!-- featurs area start here -->
        <section class="featurs-services pt-110 pb-90">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xxl-10">
                        <div class="section_title_wrapper text-center mb-50 wow fadeInUp" data-wow-delay="0.3s"
                            style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;">
                            <span class="subtitle">
                                Featured Services
                            </span>
                            <h2 class="section-title">
                                We Provide Visa & Immigration Service <br> From Experienced Lawyers
                            </h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 mb-30 wow fadeInUp" data-wow-delay="0.3s"
                        style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;">
                        <div class="features">
                            <div class="features__thumb">
                                <a href="business-visa.html"><img src="<?php echo e(asset('frontend/assets/img/featurs/featurs-1.jpg')); ?>" alt=""></a>
                            </div>
                            <div class="features__content">
                                <h3 class="features__content-title"> <a href="business-visa.html">Business Visa</a>
                                </h3>
                                <p>We helped with other family based employment based and investment based Immigration.
                                </p>
                                <a href="business-visa.html">Read More <i class="fal fa-long-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 mb-30 wow fadeInUp" data-wow-delay="0.5s"
                        style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;">
                        <div class="features">
                            <div class="features__thumb">
                                <a href="business-visa.html"><img src="<?php echo e(asset('frontend/assets/img/featurs/featurs-2.jpg')); ?>" alt=""></a>
                            </div>
                            <div class="features__content">
                                <h3 class="features__content-title"> <a href="business-visa.html">Students Visa </a>
                                </h3>
                                <p>We helped with other family based employment based and investment based Immigration.
                                </p>
                                <a href="business-visa.html">Read More <i class="fal fa-long-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 mb-30 wow fadeInUp" data-wow-delay="0.7s"
                        style="visibility: visible; animation-delay: 0.7s; animation-name: fadeInUp;">
                        <div class="features">
                            <div class="features__thumb">
                                <a href="business-visa.html"><img src="<?php echo e(asset('frontend/assets/img/featurs/featurs-3.jpg')); ?>" alt=""></a>
                            </div>
                            <div class="features__content">
                                <h3 class="features__content-title"> <a href="business-visa.html">Work & Job Visa</a>
                                </h3>
                                <p>We helped with other family based employment based and investment based Immigration.
                                </p>
                                <a href="business-visa.html">Read More <i class="fal fa-long-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.9s"
                        style="visibility: visible; animation-delay: 0.9s; animation-name: fadeInUp;">
                        <div class="features">
                            <div class="features__thumb">
                                <a href="business-visa.html"><img src="<?php echo e(asset('frontend/assets/img/featurs/featurs-4.jpg')); ?>" alt=""></a>
                            </div>
                            <div class="features__content">
                                <h3 class="features__content-title"> <a href="business-visa.html">Tourist & Visitor
                                        Visa</a> </h3>
                                <p>We helped with other family based employment based and investment based Immigration.
                                </p>
                                <a href="business-visa.html">Read More <i class="fal fa-long-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- featurs area end here -->

        <!-- Scholarship Programs start here -->
        <section class="scholarship-area d-flex align-items-center"
            style="background-image: url(<?php echo e(asset('frontend/assets/img/scholarship/scholarship-bg.jpg')); ?>);">
            <div class="container">
                <div class="row">
                    <div class="col-xxl-6 col-xl-6 col-lg-6 ">
                        <div class="scholarship-left">
                            <img src="<?php echo e(asset('frontend/assets/img/scholarship/scholarship-left.png')); ?>" alt="">
                        </div>
                    </div>
                    <div class="col-xxl-6 col-xl-6 col-lg-6 wow fadeInUp" data-wow-delay="0.3s"
                        style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;">
                        <div class="scholarship__wrapper pt-110 pb-90">
                            <h2 class="scholarship__wrapper-title mb-30">20+ Best Universities Scholarship Programs From
                                20 Countries</h2>
                            <p>We also help with other family based employment based and investment based Immigration.
                                Praesent eui vel aliquam nisl efficitur eu.</p>
                            <div class="scholarship__wrapper-img mb-40">
                                <img src="<?php echo e(asset('frontend/assets/img/scholarship/s-1.png')); ?>" alt="">
                                <img src="<?php echo e(asset('frontend/assets/img/scholarship/s-2.png')); ?>" alt="">
                                <img src="<?php echo e(asset('frontend/assets/img/scholarship/s-3.png')); ?>" alt="">
                                <img src="<?php echo e(asset('frontend/assets/img/scholarship/s-4.png')); ?>" alt="">
                                <img src="<?php echo e(asset('frontend/assets/img/scholarship/s-5.png')); ?>" alt="">
                            </div>
                            <h5>Validity From : 05 March 2021 - 25 Jan 2022</h5>
                            <a href="#" class="theme-btn blacks-hover">Apply Now </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Scholarship Programs end here -->

         <!-- About  start here -->
        <section class="about-area pt-120 pb-90">
            <div class="container">
                <div class="row wow fadeInUp" data-wow-delay="0.2s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;">
                    <div class="col-xxl-6 col-xl-6 col-lg-6 mb-30">
                        <div class="section_title_wrapper">
                            <span class="subtitle">
                                About visapass
                            </span>
                            <h2 class="section-title about-span mb-30">
                                <span>25+</span> Years of Your Trust and Recommendation
                            </h2>
                            <div class="section_title_wrapper-about-content">
                                <h5>ISO Certified & Best Immigration Award 2018 Winner </h5>
                                <p>For the last 35 years, We have helped students, business persons, tourists, clients
                                    with medical needs to acquire U.S. visas. Besides, we also help with other family
                                    based, employment based & investment based Immigration. Aenean vestibulum ornare
                                    sapien, at pharetra massa consectetur et. Aliquam sit amet ipsum</p>
                                <a href="about.html" class="theme-btn">Read More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-6 col-xl-6 col-lg-6 mb-30">
                        <div class="about_wrapper">
                            <div class="about_wrapper__certificate">
                                <img src="frontend/assets/img/about/certificate.png" alt="">
                            </div>
                            <div class="about_wrapper__group">
                                <div class="about_wrapper__group-top mb-15">
                                    <img src="<?php echo e(asset('frontend/assets/img/about/about-1.jpg')); ?>" alt="">
                                </div>
                                <div class="about_wrapper__group-btm d-flex align-items-center justify-content-end">
                                    <div class="about_wrapper__group-btm-img1 ml-30">
                                        <img src="<?php echo e(asset('frontend/assets/img/about/about-2.jpg')); ?>" alt="">
                                    </div>
                                    <div class="about_wrapper__group-btm-img2 ml-15">
                                        <img src="<?php echo e(asset('frontend/assets/img/about/about-3.jpg')); ?>" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- About  end here -->


        <!-- popularct start -->
        <section class="popularct-area pt-110 pb-160" style="background-image: url(frontend/assets/img/popularct/plr-ct.jpg);">
            <div class="container">
                <div class="row  justify-content-center">
                    <div class="col-xxl-10">
                        <div class="section_title_wrapper popularct-extra text-center">
                            <span class="subtitle">
                                Popular Countries
                            </span>
                            <h2 class="section-title">
                                Select Your Favorite Country <br> To Apply Visa
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- popularct end -->

        <!-- Country-all start -->
        <section class="country-all">
            <div class="container">
                <div class="brand-active  owl-carousel">
                    <div class="country_item__wrapper">
                        <div class="country_item__wrapper__top">
                            <div class="country_item__wrapper__top__img">
                                <img src="frontend/assets/img/country-img/c-1.jpg" alt="">
                            </div>
                            <div class="country_item__wrapper__top__icon">
                                <a href="#"><i class="fal fa-plus"></i></a>
                            </div>
                        </div>
                        <div class="country_item__wrapper__bottom">
                            <h4 class="country_item__wrapper__bottom__title">
                                <a href="#">New Zealand</a>
                            </h4>
                        </div>
                    </div>

                    <div class="country_item__wrapper">
                        <div class="country_item__wrapper__top">
                            <div class="country_item__wrapper__top__img">
                                <img src="frontend/assets/img/country-img/c-2.jpg" alt="">
                            </div>
                            <div class="country_item__wrapper__top__icon">
                                <a href="#"><i class="fal fa-plus"></i></a>
                            </div>
                        </div>
                        <div class="country_item__wrapper__bottom">
                            <h4 class="country_item__wrapper__bottom__title">
                                <a href="#">United States</a>
                            </h4>
                        </div>
                    </div>
                    <div class="country_item__wrapper">
                        <div class="country_item__wrapper__top">
                            <div class="country_item__wrapper__top__img">
                                <img src="frontend/assets/img/country-img/c-3.jpg" alt="">
                            </div>
                            <div class="country_item__wrapper__top__icon">
                                <a href="#"><i class="fal fa-plus"></i></a>
                            </div>
                        </div>
                        <div class="country_item__wrapper__bottom">
                            <h4 class="country_item__wrapper__bottom__title">
                                <a href="#">United Kingdom</a>
                            </h4>
                        </div>
                    </div>
                    <div class="country_item__wrapper">
                        <div class="country_item__wrapper__top">
                            <div class="country_item__wrapper__top__img">
                                <img src="frontend/assets/img/country-img/c-4.jpg" alt="">
                            </div>
                            <div class="country_item__wrapper__top__icon">
                                <a href="#"><i class="fal fa-plus"></i></a>
                            </div>
                        </div>
                        <div class="country_item__wrapper__bottom">
                            <h4 class="country_item__wrapper__bottom__title">
                                <a href="#">Switzerland</a>
                            </h4>
                        </div>
                    </div>
                    <div class="country_item__wrapper">
                        <div class="country_item__wrapper__top">
                            <div class="country_item__wrapper__top__img">
                                <img src="frontend/assets/img/country-img/c-3.jpg" alt="">
                            </div>
                            <div class="country_item__wrapper__top__icon">
                                <a href="#"><i class="fal fa-plus"></i></a>
                            </div>
                        </div>
                        <div class="country_item__wrapper__bottom">
                            <h4 class="country_item__wrapper__bottom__title">
                                <a href="#">United States</a>
                            </h4>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Country-all end -->

        <!-- Globall area start -->
        <section class="global-area pt-120 pb-120">
            <div class="container">
                <div class="row">
                    <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
                        <div class="section_title_wrapper global-text mb-30">
                            <span class="subtitle">
                                Global Visa Business
                            </span>
                            <h2 class="section-title">
                                We Work Globally With Partners In 80+ Popular Countries
                            </h2>
                            <p>We have helped students, business persons, tourists, clients with medical needs to
                                acquire U.S. visas. Besides, we also help with other family and provide counseling
                                services for immigration </p>
                            <div class="global-subscribe">
                                <form action="#">
                                    <input type="email" placeholder=" Enter you NID No">
                                    <button type="submit">Check Availability <i
                                            class="fal fa-long-arrow-right"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
                        <div class="global-area-img">
                            <img src="frontend/assets/img/globall/Map.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Globall area end -->

        <!-- Testimonail start -->
        <section class="testimonail-area grey-bg pt-110 pb-190">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xxl-10">
                        <div class="section_title_wrapper text-center mb-50">
                            <span class="subtitle">
                                Testimonials
                            </span>
                            <h2 class="section-title">
                                What Clients Say About Us and <br> Our Services
                            </h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="textimonail-active owl-carousel">
                        <div class="testimonail__wrapper">
                            <div class="testimonail__wrapper__info d-flex align-items-center mb-25">
                                <div class="testimonail__wrapper__info__img ">
                                    <img src="<?php echo e(asset('frontend/assets/img/testimonial/ts-1.png')); ?>" alt="">
                                </div>
                                <div class="testimonail__wrapper__info__author">
                                    <h4>Karlosh Tremon</h4>
                                    <span>Student</span>
                                </div>
                                <div class="testimonail__wrapper__info__quotes">
                                    <i class="flaticon-quote"></i>
                                </div>
                            </div>
                            <div class="testimonail__wrapper__content">
                                <p>Travellers from countries categorized under the high-risk list who are eligible to
                                    enter Germany, aged 12 and older, are obliged to present their vaccination
                                    certificates</p>
                                <div class="testimonail__wrapper__content__reviews">
                                    <ul>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li>(Switzerland Visa)</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="testimonail__wrapper">
                            <div class="testimonail__wrapper__info d-flex align-items-center mb-25">
                                <div class="testimonail__wrapper__info__img ">
                                    <img src="<?php echo e(asset('frontend/assets/img/testimonial/ts-2.png')); ?>" alt="">
                                </div>
                                <div class="testimonail__wrapper__info__author">
                                    <h4>Daniel Groveria</h4>
                                    <span>Business Man</span>
                                </div>
                                <div class="testimonail__wrapper__info__quotes">
                                    <i class="flaticon-quote"></i>
                                </div>
                            </div>
                            <div class="testimonail__wrapper__content">
                                <p>Travellers from countries categorized under the high-risk list who are eligible to
                                    enter Germany, aged 12 and older, are obliged to present their vaccination
                                    certificates</p>
                                <div class="testimonail__wrapper__content__reviews ">
                                    <ul>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li>(Switzerland Visa)</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="testimonail__wrapper">
                            <div class="testimonail__wrapper__info d-flex align-items-center mb-25">
                                <div class="testimonail__wrapper__info__img ">
                                    <img src="<?php echo e(asset('frontend/assets/img/testimonial/ts-3.png')); ?>" alt="">
                                </div>
                                <div class="testimonail__wrapper__info__author">
                                    <h4>Michel Midester</h4>
                                    <span>Traveller</span>
                                </div>
                                <div class="testimonail__wrapper__info__quotes">
                                    <i class="flaticon-quote"></i>
                                </div>
                            </div>
                            <div class="testimonail__wrapper__content">
                                <p>Travellers from countries categorized under the high-risk list who are eligible to
                                    enter Germany, aged 12 and older, are obliged to present their vaccination
                                    certificates</p>
                                <div class="testimonail__wrapper__content__reviews">
                                    <ul>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li>(Switzerland Visa)</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="testimonail__wrapper">
                            <div class="testimonail__wrapper__info d-flex align-items-center mb-25">
                                <div class="testimonail__wrapper__info__img ">
                                    <img src="<?php echo e(asset('frontend/assets/img/testimonial/ts-1.png')); ?>" alt="">
                                </div>
                                <div class="testimonail__wrapper__info__author">
                                    <h4>Daniel Groveria</h4>
                                    <span>Student</span>
                                </div>
                                <div class="testimonail__wrapper__info__quotes">
                                    <i class="flaticon-quote"></i>
                                </div>
                            </div>
                            <div class="testimonail__wrapper__content">
                                <p>Travellers from countries categorized under the high-risk list who are eligible to
                                    enter Germany, aged 12 and older, are obliged to present their vaccination
                                    certificates</p>
                                <div class="testimonail__wrapper__content__reviews">
                                    <ul>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li>(Switzerland Visa)</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="testimonail__wrapper">
                            <div class="testimonail__wrapper__info d-flex align-items-center mb-25">
                                <div class="testimonail__wrapper__info__img ">
                                    <img src="<?php echo e(asset('frontend/assets/img/testimonial/ts-2.png')); ?>" alt="">
                                </div>
                                <div class="testimonail__wrapper__info__author">
                                    <h4>Dana Holly Joya</h4>
                                    <span>Student</span>
                                </div>
                                <div class="testimonail__wrapper__info__quotes">
                                    <i class="flaticon-quote"></i>
                                </div>
                            </div>
                            <div class="testimonail__wrapper__content">
                                <p>Travellers from countries categorized under the high-risk list who are eligible to
                                    enter Germany, aged 12 and older, are obliged to present their vaccination
                                    certificates</p>
                                <div class="testimonail__wrapper__content__reviews">
                                    <ul>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li>(Switzerland Visa)</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="testimonail__wrapper">
                            <div class="testimonail__wrapper__info d-flex align-items-center mb-25">
                                <div class="testimonail__wrapper__info__img ">
                                    <img src="<?php echo e(asset('frontend/assets/img/testimonial/ts-1.png')); ?>" alt="">
                                </div>
                                <div class="testimonail__wrapper__info__author">
                                    <h4>Linkon Dicruse</h4>
                                    <span>Student</span>
                                </div>
                                <div class="testimonail__wrapper__info__quotes">
                                    <i class="flaticon-quote"></i>
                                </div>
                            </div>
                            <div class="testimonail__wrapper__content">
                                <p>Travellers from countries categorized under the high-risk list who are eligible to
                                    enter Germany, aged 12 and older, are obliged to present their vaccination
                                    certificates</p>
                                <div class="testimonail__wrapper__content__reviews">
                                    <ul>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li>(Switzerland Visa)</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="testimonail__wrapper">
                            <div class="testimonail__wrapper__info d-flex align-items-center mb-25">
                                <div class="testimonail__wrapper__info__img ">
                                    <img src="<?php echo e(asset('frontend/assets/img/testimonial/ts-3.png')); ?>" alt="">
                                </div>
                                <div class="testimonail__wrapper__info__author">
                                    <h4>Jonathon Deoya</h4>
                                    <span>Student</span>
                                </div>
                                <div class="testimonail__wrapper__info__quotes">
                                    <i class="flaticon-quote"></i>
                                </div>
                            </div>
                            <div class="testimonail__wrapper__content">
                                <p>Travellers from countries categorized under the high-risk list who are eligible to
                                    enter Germany, aged 12 and older, are obliged to present their vaccination
                                    certificates</p>
                                <div class="testimonail__wrapper__content__reviews">
                                    <ul>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li><i class="fas fa-star"></i></li>
                                        <li>(Switzerland Visa)</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Testimonail end -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/canadavi/public_html/resources/views/frontend/index.blade.php ENDPATH**/ ?>