

    <!-- preloader -->
    
    <!-- preloader end  -->

    <!-- back to top start -->
    <div class="progress-wrap">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
        </svg>
    </div>
    <!-- back to top end -->

    <!-- header area start here -->
    <header>
        <div class="header-menu header-sticky">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-xxl-2 col-xl-2 col-lg-2 col-8">
                        <div class="header-logo ">
                            <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('frontend/assets/img/logo/logo.png')); ?>" class="img-fluid" alt="img"></a>
                        </div>
                    </div>
                    <div class="col-xxl-7 col-xl-7 col-lg-7 col-4">
                        <div class="main-menu d-none d-lg-block ">
                            <nav id="mobile-menu">
                                <ul>
                                    <li><a href="<?php echo e(url('/')); ?>">HOME</a></li>
                                    <li><a href="<?php echo e(route('checkstatus')); ?>">Visa Status Check</a></li>
                                    <li class=""><a href="#">PAGES</a>
                                        
                                    </li>
                                    <li><a href="#">CONTACT</a></li>
                                </ul>
                            </nav>
                        </div>
                        <div class="side-menu-icon d-lg-none text-end">
                            <button class="side-toggle"><i class="far fa-bars"></i></button>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-3 col-lg-3">
                        <div class="main-menu-wrapper d-flex align-items-center justify-content-end">
                            <div class="main-menu-wrapper__search text-left">
                                <a class="search-btn nav-search search-trigger" href="#"><i
                                        class="fal fa-search"></i></a>
                            </div>
                            <div class="main-menu-wrapper__call-number d-flex align-items-center">
                                <div class="main-menu-wrapper__call-icon mr-10">
                                    <img src="<?php echo e(asset('frontend/assets/img/menu-icon/chatting.png')); ?>" alt="">
                                </div>
                                <div class="main-menu-wrapper__call-text">
                                    <span>Contact Us</span>
                                    <h5><a href="tel:(555)58023059">(555) 5802 3059</a></h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="offcanvas-overlay"></div>
        <div class="fix">
            <div class="side-info">
                <button class="side-info-close"><i class="fal fa-times"></i></button>
                <div class="side-info-content">
                    <div class="mobile-menu"></div>
                </div>
            </div>
        </div>
    </header>

    <!-- Fullscreen search -->
    <div class="search-wrap">
        <div class="search-inner">
            <i class="fal fa-times search-close" id="search-close"></i>
            <div class="search-cell">
                <form method="get">
                    <div class="search-field-holder">
                        <input type="search" class="main-search-input" placeholder="Search Entire Store...">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- end fullscreen search -->

    <!-- header area end here -->
<?php /**PATH /home/canadavi/public_html/resources/views/frontend/layouts/header.blade.php ENDPATH**/ ?>